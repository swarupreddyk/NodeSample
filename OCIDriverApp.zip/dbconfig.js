module.exports = {
  user          : process.env["DBAAS_USER_NAME"],
  password      : process.env["DBAAS_USER_PASSWORD"],
  connectString : process.env['DBAAS_DEFAULT_CONNECT_DESCRIPTOR']
};

